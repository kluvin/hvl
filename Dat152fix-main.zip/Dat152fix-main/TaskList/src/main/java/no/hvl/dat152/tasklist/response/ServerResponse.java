package no.hvl.dat152.tasklist.response;

public class ServerResponse {
	private Boolean responseStatus = false;

	public Boolean getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(Boolean responseStatus) {
		this.responseStatus = responseStatus;
	}
}
